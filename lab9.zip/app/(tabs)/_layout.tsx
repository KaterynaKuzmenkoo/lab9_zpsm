import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Drawer } from 'expo-router/drawer';
import WelcomeScreen from './WelcomeScreen';
import { View, ActivityIndicator } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';

export default function RootLayout() {
  const [isFirstLaunch, setIsFirstLaunch] = useState<boolean | null>(null);

  useEffect(() => {

    SplashScreen.preventAutoHideAsync();
    const checkFirstLaunch = async () => {
      const hasLaunched = await AsyncStorage.getItem('hasLaunched');
      if (hasLaunched === null) {
        // Pierwsze uruchomienie
        await AsyncStorage.setItem('hasLaunched', 'true');
        setIsFirstLaunch(true);
      } else {
        setIsFirstLaunch(false);
      }
      SplashScreen.hideAsync();
    };

    checkFirstLaunch();
  }, []);

  if (isFirstLaunch === null) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#4CAF50" />
      </View>
    );
  }

  if (isFirstLaunch) {
    return <WelcomeScreen />;
  }

  return (
    <Drawer
      screenOptions={{
        drawerStyle: { backgroundColor: '#e6e6e6', width: 240 },
        headerStyle: { backgroundColor: '#4CAF50' },
        headerTintColor: '#fff',
        drawerActiveTintColor: '#4CAF50',
      }}
    >
      <Drawer.Screen name="index" options={{ title: 'Ekran Główny' }} />
      <Drawer.Screen name="TestScreen" options={{ title: 'Test' }} />
      <Drawer.Screen name="ResultsScreen" options={{ title: 'Rezultaty' }} />
    </Drawer>
  );
}
