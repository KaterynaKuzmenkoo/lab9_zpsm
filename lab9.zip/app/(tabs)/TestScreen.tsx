// Modified TestScreen.tsx
import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, ProgressBarAndroid, Alert } from 'react-native';
const tasks = [
  {
    question: "Który wódz po śmierci Gajusza Mariusza prowadził wojnę domową z Sullą?",
    answers: [
      { content: "LUCJUSZ CYNNA", isCorrect: true },
      { content: "JULIUSZ CEZAR", isCorrect: false },
      { content: "LUCJUSZ MURENA", isCorrect: false },
      { content: "MAREK KRASSUS", isCorrect: false },
    ],
    duration: 30,
  },
  
  {
    question: "Jakie państwo jest największe pod względem powierzchni?",
    answers: [
      { content: "Rosja", isCorrect: true },
      { content: "Kanada", isCorrect: false },
      { content: "Chiny", isCorrect: false },
      { content: "Stany Zjednoczone", isCorrect: false },
    ],
    duration: 30,
  },
  {
    question: "Kiedy Polska odzyskała niepodległość?",
    answers: [
      { content: "1918", isCorrect: true },
      { content: "1920", isCorrect: false },
      { content: "1939", isCorrect: false },
      { content: "1945", isCorrect: false },
    ],
  },
  {question: "Kto był pierwszym królem Polski?",
  answers: [
    { content: "MIESZKO I", isCorrect: false },
    { content: "BOLESŁAW CHROBRY", isCorrect: true },
    { content: "KAZIMIERZ WIELKI", isCorrect: false },
    { content: "WŁADYSŁAW ŁOKIETEK", isCorrect: false },
  ],},
  {
    question: "Który rok uznaje się za początek średniowiecza?",
    answers: [
      { content: "476", isCorrect: true },
      { content: "1492", isCorrect: false },
      { content: "800", isCorrect: false },
      { content: "962", isCorrect: false },
    ],
  },
];

const TestScreen: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [progress, setProgress] = useState(0);
  const [total] = useState(tasks.length);

  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 1);
    }
    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < tasks.length) {
      setCurrentQuestion(nextQuestion);
      setProgress(nextQuestion / tasks.length);
    } else {
      // Wywołanie submitResults tylko po zakończeniu quizu
      const finalScore = score + (isCorrect ? 1 : 0);
      submitResults("Ka", finalScore, tasks.length, "historia");
      Alert.alert("Koniec quizu!", `Twój wynik to: ${finalScore}/${tasks.length}`);
    }
  };
    const questionData = tasks[currentQuestion];

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Quiz</Text>
      <View style={styles.progressContainer}>
        <Text style={styles.progressText}>{`Pytanie ${currentQuestion + 1} z ${tasks.length}`}</Text>
      </View>
      <ProgressBarAndroid
        styleAttr="Horizontal"
        color="#007BFF"
        progress={progress}
        style={styles.progressBar}
      />
      <Text style={styles.question}>{questionData.question}</Text>
      <View style={styles.answersContainer}>
        {questionData.answers.map((answer, index) => (
          <TouchableOpacity
            key={index}
            style={styles.answerButton}
            onPress={() => handleAnswer(answer.isCorrect)}
          >
            <Text style={styles.answerText}>{answer.content}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const sendResults = async (nick: string, score: number, total: number, type: string) => {
  const resultData = {
    nick: nick,
    score: score,
    total: total,
    type: type,
  };

  try {
    const response = await fetch('https://tgryl.pl/quiz/result', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(resultData),
    });

    if (!response.ok) {
      console.error('Błąd HTTP:', response.status);
      return;
    }

    const responseBody = await response.json(); // Odczytaj JSON tylko raz
    console.log('Odpowiedź serwera:', responseBody);

    // Sprawdź, czy odpowiedź zawiera wymagane dane
    if (responseBody.id && responseBody.createdOn) {
      console.log('Wyniki zostały wysłane pomyślnie!');
    } else {
      console.error('Błąd zapisu wyników: brak wymaganych danych w odpowiedzi', responseBody);
    }
  } catch (error) {
    console.error('Błąd połączenia:', error);
  }
};

// Przykład użycia
const submitResults = (nick:string, score:number, total:number, type:string) => {
  sendResults(nick, score, total, type);
};


const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 16 },
  progressContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressText: { fontSize: 14, color: '#555' },
  progressBar: { height: 10, borderRadius: 5, overflow: 'hidden', marginBottom: 16 },
  question: { fontSize: 18, fontWeight: 'bold', marginBottom: 8, textAlign: 'center' },
  answersContainer: { flexDirection: 'column', gap: 8 },
  answerButton: { padding: 16, backgroundColor: '#e6f7ff', borderRadius: 8, alignItems: 'center', marginVertical: 6, borderWidth: 1, borderColor: '#007BFF' },
  answerText: { fontSize: 16, fontWeight: 'bold' },
});

export default TestScreen;