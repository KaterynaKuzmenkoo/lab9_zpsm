export const tasks = {
    historia: [
      {
        question: "Który wódz po śmierci Gajusza Mariusza prowadził wojnę domową z Sullą?",
        answers: [
          { content: "LUCJUSZ CYNNA", isCorrect: true },
          { content: "JULIUSZ CEZAR", isCorrect: false },
          { content: "LUCJUSZ MURENA", isCorrect: false },
          { content: "MAREK KRASSUS", isCorrect: false },
        ],
      },
      {
        question: "Kiedy Polska odzyskała niepodległość?",
        answers: [
          { content: "1918", isCorrect: true },
          { content: "1920", isCorrect: false },
          { content: "1939", isCorrect: false },
          { content: "1945", isCorrect: false },
        ],
      },
      {question: "Kto był pierwszym królem Polski?",
      answers: [
        { content: "MIESZKO I", isCorrect: false },
        { content: "BOLESŁAW CHROBRY", isCorrect: true },
        { content: "KAZIMIERZ WIELKI", isCorrect: false },
        { content: "WŁADYSŁAW ŁOKIETEK", isCorrect: false },
      ],},
      {
        question: "Który rok uznaje się za początek średniowiecza?",
        answers: [
          { content: "476", isCorrect: true },
          { content: "1492", isCorrect: false },
          { content: "800", isCorrect: false },
          { content: "962", isCorrect: false },
        ],
      },
    ],
    matematyka: [
      {
        question: "Ile wynosi pierwiastek z 16?",
        answers: [
          { content: "4", isCorrect: true },
          { content: "5", isCorrect: false },
          { content: "6", isCorrect: false },
          { content: "8", isCorrect: false },
        ],
      },
      {
        question: "Ile wynosi 7 + 5?",
        answers: [
          { content: "12", isCorrect: true },
          { content: "10", isCorrect: false },
          { content: "15", isCorrect: false },
          { content: "11", isCorrect: false },
        ],
      },
      // Dodaj więcej pytań
    ],
    geografia: [
      {
        question: "Najdłuższa rzeka świata to?",
        answers: [
          { content: "Amazonka", isCorrect: true },
          { content: "Nil", isCorrect: false },
          { content: "Jangcy", isCorrect: false },
          { content: "Missisipi", isCorrect: false },
        ],
      },
      {
        question: "Stolica Francji to?",
        answers: [
          { content: "Paryż", isCorrect: true },
          { content: "Londyn", isCorrect: false },
          { content: "Rzym", isCorrect: false },
          { content: "Berlin", isCorrect: false },
        ],
      },
      // Dodaj więcej pytań
    ],
    biologia: [
      {
        question: "Który organ jest odpowiedzialny za pompowanie krwi?",
        answers: [
          { content: "Serce", isCorrect: true },
          { content: "Mózg", isCorrect: false },
          { content: "Płuca", isCorrect: false },
          { content: "Żołądek", isCorrect: false },
        ],
      },
      {
        question: "Jaki pierwiastek jest niezbędny do oddychania komórkowego?",
        answers: [
          { content: "Tlen", isCorrect: true },
          { content: "Wodór", isCorrect: false },
          { content: "Azot", isCorrect: false },
          { content: "Hel", isCorrect: false },
        ],
      },
      // Dodaj więcej pytań
    ],
  };
  