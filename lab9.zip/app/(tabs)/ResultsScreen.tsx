import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl } from 'react-native';

// Definicja typu dla wyników
interface Result {
  id: string;
  nick: string;
  score: number;
  total: number;
  type: string;
  date: string;
}

const ResultsScreen: React.FC = () => {
  const [results, setResults] = useState<Result[]>([]); // Typ tablicy wyników
  const [refreshing, setRefreshing] = useState(false);

  // Funkcja do pobierania danych z API
  const fetchResults = async () => {
    try {
      const response = await fetch('https://tgryl.pl/quiz/results?last=20');
      const data: Result[] = await response.json(); // Oczekujemy, że dane są typu Result[]
      setResults(data);
    } catch (error) {
      console.error('Error fetching results:', error);
    }
  };

  // Pobierz wyniki przy załadowaniu komponentu
  useEffect(() => {
    fetchResults();
  }, []);

  // Funkcja odświeżania
  const onRefresh = () => {
    setRefreshing(true);
    fetchResults().finally(() => setRefreshing(false));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Wyniki</Text>
      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={styles.cell}>{item.nick}</Text>
            <Text style={styles.cell}>{`${item.score}/${item.total}`}</Text>
            <Text style={styles.cell}>{item.type}</Text>
            <Text style={styles.cell}>{item.date}</Text>
          </View>
        )}
        ListHeaderComponent={() => (
          <View style={[styles.row, styles.headerRow]}>
            <Text style={[styles.cell, styles.headerCell]}>Nick</Text>
            <Text style={[styles.cell, styles.headerCell]}>Wynik</Text>
            <Text style={[styles.cell, styles.headerCell]}>Typ</Text>
            <Text style={[styles.cell, styles.headerCell]}>Data</Text>
          </View>
        )}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#4CAF50']}
          />
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  headerRow: { backgroundColor: '#f0f0f0', borderBottomWidth: 2, borderBottomColor: '#ccc' },
  cell: { flex: 1, textAlign: 'center', fontSize: 14 },
  headerCell: { fontWeight: 'bold', fontSize: 16 },
});

export default ResultsScreen;
