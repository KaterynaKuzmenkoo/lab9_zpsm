import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useRouter } from 'expo-router';

// Definicja typu dla testu
type Test = {
  id: string;
  name: string;
  tags: string[];
  description: string;
};

const HomeScreen: React.FC = () => {
  const router = useRouter();
  const [tests, setTests] = useState<Test[]>([]); // Użycie typu Test[]
  const [loading, setLoading] = useState(true);

  // Pobieranie listy testów z API
  useEffect(() => {
    const fetchTests = async () => {
      try {
        const response = await fetch('https://tgryl.pl/quiz/tests');
        if (!response.ok) throw new Error(`HTTP status ${response.status}`);
        const data: Test[] = await response.json(); // Rzutowanie odpowiedzi na typ Test[]
        setTests(data); // Zapisz pobrane testy w stanie
      } catch (error) {
        console.error('Błąd podczas pobierania testów:', error);
        Alert.alert('Błąd', 'Nie udało się pobrać testów. Spróbuj ponownie później.');
      } finally {
        setLoading(false); // Ustaw zakończenie ładowania
      }
    };

    fetchTests();
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007BFF" />
        <Text>Ładowanie testów...</Text>
      </View>
    );
  }

  if (tests.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Brak dostępnych testów</Text>
        <Text style={styles.infoText}>Spróbuj ponownie później.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Home Page</Text>
      <FlatList
        data={tests}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => router.push(`/TestScreen?id=${item.id}`)} // Przejście do szczegółów testu
          >
            <Text style={styles.title}>{item.name}</Text>
            <View style={styles.tagContainer}>
              {item.tags.map((tag, index) => (
                <Text key={index} style={styles.tag}>
                  {tag}
                </Text>
              ))}
            </View>
            <Text style={styles.description}>{item.description}</Text>
          </TouchableOpacity>
        )}
      />
      <View style={styles.footer}>
        <Text style={styles.footerText}>Get to know your ranking result</Text>
        <Button title="Check!" onPress={() => router.push('/ResultsScreen')} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 16 },
  card: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    backgroundColor: '#f9f9f9',
  },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  tagContainer: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
  tag: {
    backgroundColor: '#e6f7ff',
    color: '#007BFF',
    padding: 4,
    borderRadius: 4,
    fontSize: 12,
    marginRight: 4,
    marginBottom: 4,
  },
  description: { fontSize: 14, color: '#333' },
  footer: { alignItems: 'center', marginTop: 16 },
  footerText: { fontSize: 16, marginBottom: 8 },
  infoText: { fontSize: 16, color: '#555', textAlign: 'center' },
});

export default HomeScreen;
