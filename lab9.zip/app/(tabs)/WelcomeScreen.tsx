import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

export default function WelcomeScreen() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Regulamin Aplikacji</Text>
      <Text style={styles.text}>
        Tutaj możesz dodać treść regulaminu aplikacji. Upewnij się, że użytkownik
        go przeczyta i zaakceptuje.
      </Text>
      <Button
        title="Akceptuję"
        onPress={() => router.replace('/')} 
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
  },
});
